package com.example.pdf2cbz

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipStoredWriter {
    fun addStored(zip: ZipOutputStream, file: File, name: String) {
        val crc = CRC32()
        var size = 0L

        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                crc.update(buffer, 0, n)
                size += n
            }
        }

        val entry = ZipEntry(name).apply {
            method = ZipEntry.STORED
            size = size
            compressedSize = size
            crc = crc.value
        }

        zip.putNextEntry(entry)
        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                zip.write(buffer, 0, n)
            }
        }
        zip.closeEntry()
    }
}
