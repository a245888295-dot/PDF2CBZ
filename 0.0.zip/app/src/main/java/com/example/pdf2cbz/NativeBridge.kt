package com.example.pdf2cbz

object NativeBridge {
    private var loaded = false

    init {
        try {
            System.loadLibrary("pdf2cbz_poppler")
            loaded = true
        } catch (_: Throwable) {
            loaded = false
        }
    }

    external fun cancelNative()

    external fun backendStatus(): String

    fun isAvailable(): Boolean = loaded
}
