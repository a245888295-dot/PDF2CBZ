package com.example.pdf2cbz

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipStoredWriter {
    fun addStoredFile(zip: ZipOutputStream, file: File, name: String) {
        val crc = CRC32()
        var size = 0L

        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                crc.update(buffer, 0, n)
                size += n
            }
        }

        val entry = ZipEntry(name).apply {
            method = ZipEntry.STORED
            this.size = size
            this.compressedSize = size
            this.crc = crc.value
        }

        zip.putNextEntry(entry)
        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                zip.write(buffer, 0, n)
            }
        }
        zip.closeEntry()
    }

    fun addStoredBytes(zip: ZipOutputStream, bytes: ByteArray, name: String) {
        val crc = CRC32().apply { update(bytes, 0, bytes.size) }
        val entry = ZipEntry(name).apply {
            method = ZipEntry.STORED
            size = bytes.size.toLong()
            compressedSize = bytes.size.toLong()
            this.crc = crc.value
        }

        zip.putNextEntry(entry)
        zip.write(bytes)
        zip.closeEntry()
    }
}
