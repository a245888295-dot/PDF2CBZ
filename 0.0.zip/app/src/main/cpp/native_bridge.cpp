
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <string>

#define LOG_TAG "PDF2CBZ"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::atomic_bool g_cancel{false};

extern "C" JNIEXPORT void JNICALL
Java_com_example_pdf2cbz_NativeBridge_cancelNative(JNIEnv*, jobject) {
    g_cancel.store(true);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_pdf2cbz_NativeBridge_backendStatus(JNIEnv* env, jobject) {
#ifdef PDF2CBZ_POPPLER_SOURCE
    const std::string s =
        "Native build configured with Poppler source: " PDF2CBZ_POPPLER_SOURCE;
#else
    const std::string s = "Native backend placeholder";
#endif
    return env->NewStringUTF(s.c_str());
}
