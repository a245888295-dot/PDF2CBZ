# Android Poppler 后端

需要在 Linux/macOS/Windows WSL 上准备 Android NDK，并交叉编译 Poppler。

推荐 ABI：
- arm64-v8a：现代 Android 手机/平板主力
- armeabi-v7a：旧设备（可选）
- x86_64：模拟器/部分设备（可选）

目标不是把桌面 `pdfimages` 可执行文件塞进 APK，而是把 Poppler core 作为 Android shared library，并由 JNI 调用。

完成后将对应 `.so` 放入：

app/src/main/jniLibs/arm64-v8a/

并在 CMake 中通过 IMPORTED library 链接。

注意：Poppler 的依赖也必须为 Android ABI 构建，不能把 Linux x86_64 `.so` 直接放进去。

官方 Poppler：
https://poppler.freedesktop.org/

## 验证

安装 APK 后日志必须显示：

Poppler native backend interface present

并且转换任务中页面日志出现：

DIRECT / RENDER

只有 DIRECT 页面才代表“原 PDF 图片对象未重新编码”。
