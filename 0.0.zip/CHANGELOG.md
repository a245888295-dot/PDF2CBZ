# Changelog

## 2.0.0
- 原图优先架构
- Poppler JNI backend contract
- SAF PDF/目录选择
- ZIP STORED writer
- 页面 DIRECT / RENDER 分层
- 明确区分“原始图片无损”和“渲染后 PNG 无损”
- 不再把 PdfRenderer 当成所谓“原图提取”
