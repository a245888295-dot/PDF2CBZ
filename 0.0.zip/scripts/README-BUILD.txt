
你只需要做这几步：

1. 在云电脑安装 Android Studio。
2. 打开本项目。
3. Tools -> SDK Manager -> SDK Tools：
   勾选 Android SDK Command-line Tools、NDK (Side by side)、CMake。
   Android 官方说明 Android Studio/Gradle 可以自动安装 NDK 和 CMake。
4. 关闭 Android Studio。
5. 打开项目目录里的 scripts/build_poppler_android.ps1（Windows PowerShell）
   或 scripts/build_poppler_android.sh（Linux/WSL）。
6. 脚本完成后，重新打开 Android Studio。
7. Build -> Make Project。
8. Build -> Build App Bundle(s) / APK(s) -> Build APK(s)。
9. APK 在 app/build/outputs/apk/debug/app-debug.apk。

如果是 Windows 云电脑，优先用 PowerShell 脚本。
如果是 Ubuntu/WSL，使用 .sh。

第一次构建需要下载 Poppler 和其 Android 依赖，因此会比较久。
