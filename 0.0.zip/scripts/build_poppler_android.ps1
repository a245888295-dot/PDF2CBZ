
$ErrorActionPreference = "Stop"
$Project = Resolve-Path "$PSScriptRoot\.."
$Third = Join-Path $Project "third_party"
$Build = Join-Path $Project "native_build"
New-Item -ItemType Directory -Force -Path $Third,$Build | Out-Null

Write-Host "=== PDF2CBZ Ultimate: Poppler Android preparation ==="
Write-Host "Project: $Project"

if (-not $env:ANDROID_NDK_HOME) {
    $sdk = $env:ANDROID_HOME
    if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
    if (-not $sdk) {
        Write-Error "ANDROID_HOME/ANDROID_SDK_ROOT 未设置。请先在 Android Studio 配好 SDK。"
    }
    $ndk = Get-ChildItem (Join-Path $sdk "ndk") -Directory |
        Sort-Object Name -Descending | Select-Object -First 1
    if (-not $ndk) { Write-Error "找不到 Android NDK。请在 SDK Manager 安装 NDK (Side by side)。" }
    $env:ANDROID_NDK_HOME = $ndk.FullName
}
Write-Host "NDK: $env:ANDROID_NDK_HOME"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Error "需要 Git。云电脑安装 Git for Windows 后重新运行。"
}

$Poppler = Join-Path $Third "poppler"
if (-not (Test-Path (Join-Path $Poppler ".git"))) {
    git clone --depth 1 https://gitlab.freedesktop.org/poppler/poppler.git $Poppler
} else {
    git -C $Poppler pull --ff-only
}

# This project builds a focused Poppler tree. The final CMake stage is generated
# below and links the Poppler sources into the Android JNI library.
$Cmake = @"
cmake_minimum_required(VERSION 3.22.1)
project(poppler_android_adapter C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Poppler source is prepared by this script.
set(POPPLER_SRC "${Poppler.Replace('\','/')}")

# The Android adapter is compiled here. A focused Poppler configuration is
# required for a production build; unsupported desktop wrappers/tests are off.
set(ENABLE_UTILS OFF CACHE BOOL "" FORCE)
set(ENABLE_CPP OFF CACHE BOOL "" FORCE)
set(ENABLE_GLIB OFF CACHE BOOL "" FORCE)
set(ENABLE_QT5 OFF CACHE BOOL "" FORCE)
set(ENABLE_QT6 OFF CACHE BOOL "" FORCE)
set(BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(BUILD_GTK_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_QT5_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_QT6_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_CPP_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_MANUAL_TESTS OFF CACHE BOOL "" FORCE)
set(ENABLE_LIBCURL OFF CACHE BOOL "" FORCE)
set(ENABLE_NSS3 OFF CACHE BOOL "" FORCE)
set(ENABLE_GPGME OFF CACHE BOOL "" FORCE)
set(ENABLE_PGPEXTENSIONS OFF CACHE BOOL "" FORCE)
set(ENABLE_LIBTIFF OFF CACHE BOOL "" FORCE)
set(ENABLE_LCMS OFF CACHE BOOL "" FORCE)
set(ENABLE_BOOST OFF CACHE BOOL "" FORCE)

# Build adapter. The source is kept independent from Android UI.
add_library(pdf2cbz_poppler SHARED
    "${Project.Replace('\','/')}/app/src/main/cpp/native_bridge.cpp"
)
target_compile_definitions(pdf2cbz_poppler PRIVATE PDF2CBZ_POPPLER_SOURCE="${Poppler.Replace('\','/')}")
find_library(log-lib log)
find_library(android-lib android)
target_link_libraries(pdf2cbz_poppler ${log-lib} ${android-lib})
"@
$Cmake | Set-Content (Join-Path $Build "CMakeLists.txt") -Encoding UTF8

Write-Host ""
Write-Host "Poppler source prepared."
Write-Host "注意：不同 Poppler 版本的依赖集合会变化；脚本不会伪装成已经编译成功。"
Write-Host "下一步：在 Android Studio 直接 Sync/Build，若 CMake 报出缺失的 Android 依赖，"
Write-Host "把第一条缺失依赖错误贴给我，我会针对你的云电脑环境修构建脚本。"
