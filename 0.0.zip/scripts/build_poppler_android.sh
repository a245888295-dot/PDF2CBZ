#!/usr/bin/env bash
set -euo pipefail
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
THIRD="$PROJECT/third_party"
mkdir -p "$THIRD"

if [[ -z "${ANDROID_NDK_HOME:-}" ]]; then
  SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
  if [[ -z "$SDK" ]]; then
    echo "请先设置 ANDROID_HOME 或 ANDROID_SDK_ROOT"
    exit 1
  fi
  export ANDROID_NDK_HOME="$(ls -d "$SDK"/ndk/* | sort -V | tail -1)"
fi

command -v git >/dev/null || { echo "需要 git"; exit 1; }

if [[ ! -d "$THIRD/poppler/.git" ]]; then
  git clone --depth 1 https://gitlab.freedesktop.org/poppler/poppler.git "$THIRD/poppler"
else
  git -C "$THIRD/poppler" pull --ff-only
fi

echo "Poppler source prepared at $THIRD/poppler"
echo "下一步请在 Android Studio Sync/Build。"
echo "如果 CMake 报缺少 Android 依赖，把第一条错误发给我，我会继续把依赖链补齐。"
