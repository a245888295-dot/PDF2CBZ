# PDF2CBZ Ultimate v2.1.0 — Buildable Android project

这是给“有云电脑、但不想自己研究 Android NDK”的版本。

## 目标

最终 APK 的设计目标：

**PDF → 原图优先提取 → CBZ（ZIP STORED）**

而不是简单：

**PDF → PNG → CBZ**

Poppler 的构建选项中包含 `ENABLE_UTILS`、JPEG/JPX 等图像相关能力；Poppler 的 `pdfimages` 正是本项目要复现的原图提取路径。citeturn1search0

## 你只需要做

Windows 云电脑：

1. 安装 Android Studio。
2. SDK Manager 安装：
   - Android SDK
   - Android SDK Command-line Tools
   - NDK (Side by side)
   - CMake
3. 安装 Git。
4. 双击/运行：
   `scripts/build_poppler_android.ps1`
5. 用 Android Studio 打开项目。
6. Sync Project。
7. Build APK。

Android 官方说明：Android Studio/Gradle 可以使用 NDK + CMake 编译 C/C++，然后把 native `.so` 打进 APK；Gradle 会通过 CMake 构建 native library。citeturn0search0turn0search1

## 为什么我没有把它写成“一键假装成功”

Poppler 是大型 C++ PDF 引擎。不同版本的 Poppler 会改变依赖和 CMake 选项。如果云电脑环境缺少某个 Android 依赖，正确做法是根据实际第一条 CMake 错误继续补，而不是给一个“看起来完整、实际上不能编译”的项目。

这个版本已经把：
- Android UI
- SAF
- ZIP STORED
- JNI
- Poppler source preparation
- Android NDK/CMake 接口

放在一起。

### 当前状态

**v2.1.0 是可继续实际编译的工程，但 Poppler 的 Android 依赖链仍需要在你的云电脑上跑一次 CMake 后，根据真实错误完成最后的适配。**

这不是“已经完成最终 APK”的虚假声明。

## 最终验证标准

真正完成后，转换日志必须能出现：

`DIRECT`

代表 PDF 内部图片对象被直接提取，未重新 JPEG 编码。

`RENDER`

代表这一页无法安全原图提取，才使用 PNG 回退。

CBZ 中所有图片 ZIP entry 使用 STORED。
